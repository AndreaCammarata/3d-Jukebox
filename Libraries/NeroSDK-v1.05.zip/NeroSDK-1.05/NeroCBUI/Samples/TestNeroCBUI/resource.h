//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestNeroCBUI.rc
//
#define IDD_TESTNEROCBUI_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_BURN_DLG                    130
#define IDC_TEST_ERASE_DISC             1000
#define IDC_TEST_DISC_INFO              1001
#define IDC_TEST_BURN_PROGRESS          1002
#define IDC_TEST_ERASE_DISC_MODELESS    1003
#define IDC_TEST_BURN_SETTINGS          1004
#define IDC_RECORDER                    1005
#define IDC_TEST_BURN_SETTINGS_OLE      1006
#define IDC_TEST_IMAGE_INFO             1007
#define IDC_TEST_IMAGE_INFO_OLE         1008
#define IDC_TEST_CHOOSE_RECORDER        1009
#define IDC_TEST_CHOOSE_SESSION         1010
#define IDC_LANG_COMBO                  1011
#define IDC_MODAL_ERASE_DISC            1012
#define IDC_TEST_WAIT_FOR_MEDIA         1013
#define IDC_WRITESPEEDS                 1014
#define IDC_MEDIA_COMBO                 1015
#define IDC_BURN_WIZARD_MODE            1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
