NeroAPIGlue.lib: 
   NeroAPI glue library for use with Visual C++ 6 linked statically with the C runtime library

NeroAPIGlueRT.lib: 
   NeroAPI glue library for use with Visual C++ 6 linked dynamically with the C runtime library

NeroAPIGlueBCPPB.lib: 
   NeroAPI glue library for use with Borland C++Builder 6